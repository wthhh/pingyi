package com.linkstudio.service;

import com.linkstudio.entity.Teacher;

public interface ITeacherService {

    public Teacher getteacherById(String school );


}


